package codigoEscambot;

import java.text.SimpleDateFormat;

public class Mercado extends Produto{
    private String cor;
    private String marca;
    private String utilidade;
    private SimpleDateFormat datadevalidade_;
    private String datadevalidade;

    public String getCor() {
        return cor;
    }

    public String getMarca() {
        return marca;
    }

    public String getUtilidade() {
        return utilidade;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setUtilidade(String utilidade) {
        this.utilidade = utilidade;
    }

    public Mercado(String nome, int rating, String tipo, String cor, String marca, String utilidade, String datadevalidade){
        super(nome, rating, tipo);
        this.cor = cor;
        this.marca = marca;
        this.utilidade = utilidade;
        this.datadevalidade = datadevalidade;
    }

    public String getDatadevalidade() {
        return datadevalidade;
    }

    public void setDatadevalidade(String datadevalidade) {
        this.datadevalidade = datadevalidade;
    }
    
    
    
}
