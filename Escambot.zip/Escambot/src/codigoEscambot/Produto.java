
package codigoEscambot;

public class Produto {
    protected String nome;
    protected int rating;
    protected String tipo;

    public String getNome() {
        return nome;
    }

    public int getRating() {
        return rating;
    }

    public String getTipo() {
        return tipo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Produto(String nome, int rating, String tipo) {
        this.nome = nome;
        this.rating = rating;
        this.tipo = tipo;
    }
    
    
    
}
