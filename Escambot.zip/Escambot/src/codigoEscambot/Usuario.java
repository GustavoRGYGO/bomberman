package codigoEscambot;
import java.util.ArrayList;
import java.text.SimpleDateFormat;

public class Usuario extends Pessoa{
    private String cidade;
    private String telefone;
    public ArrayList<Produto> produtos_user = new ArrayList();
    
    
    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }




    public Usuario(String cidade, String telefone, String nome, String data, String cpf, String senha, String login) {
        super(nome, data, cpf, senha, login);
        this.cidade = cidade;
        this.telefone = telefone;
       
    }
    
    public Usuario(){
        
    }
    
    public boolean isSenha(String senha){
        if(this.senha.equals(senha)){
            return true;
        }else{
            return false;
        }
    }
    
    
    
}