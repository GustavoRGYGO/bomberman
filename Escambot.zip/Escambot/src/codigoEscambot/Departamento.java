
package codigoEscambot;

public class Departamento extends Produto{
    private String cor;
    private String marca;
    private String utilidade;

    
    public String getCor() {
        return cor;
    }

    public String getMarca() {
        return marca;
    }

    public String getUtilidade() {
        return utilidade;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setUtilidade(String utilidade) {
        this.utilidade = utilidade;
    }

    public Departamento(String nome, int rating, String tipo, String cor, String marca, String utilidade) {
        super(nome, rating, tipo);
        this.cor = cor;
        this.marca = marca;
        this.utilidade = utilidade;
    }
    
    
    
}
